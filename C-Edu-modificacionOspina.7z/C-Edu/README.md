# C-Edu

Este proyecto está en formato PHP y debe estar ubicado en la carpeta `htdocs` de XAMPP.

## Conectar a Visual Studio desde la terminal

Para abrir y editar este proyecto en Visual Studio desde la terminal, sigue estos pasos:

1. Asegúrate de que Visual Studio esté instalado en tu máquina.
2. Abre la terminal.
3. Navega a la carpeta `htdocs` de XAMPP donde se encuentra tu proyecto. Por ejemplo:
   ```sh
   cd C:\xampp\htdocs
   git clone https://github.com/Nico08ben/C-Edu.git
