<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./index.css">
    <title>Inicio Sesión Administrador</title>
</head>
<body>
    <header></header>
    <main>
    <div class="container">
        <div class="Login-container">
            <h1 id="Titulo-Login">Iniciar Sesión</h1>
            <p id="Subtitulo-login">ADMINISTRADORES</p>
            <form class="Login" action="/C-Edu/Administrador/Home/index.php">
                <p id="p-usuario">Usuario</p>
                <input id="campo-usuario" type="text" placeholder="Usuario">
                <p id="p-contraseña">Contraseña</p>
                <input id="campo-contraseña" type="password" placeholder="Contraseña">
                <button id="button-login" type="submit">INICIAR</button>
            </form>
        </div>
        <div class="Docente-container">
            <h2 id="titulo-docente">¿DOCENTE?</h2>
            <p id="p-docente">Inicia sesión en nuestro apartado de Docentes para poder ingresar a nuestra página web en modo Docentes.</p>
            <a href="../../index.php">
                <button id="button-docente">Iniciar Sesión</button>
            </a>
        </div>
    </div>
    </main>
    <footer></footer>
</body>
</html>